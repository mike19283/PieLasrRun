LAST RUN HISTORY FOR IATEYOURPIE

This is a program that creates a twitch chat bot for you. This app is designed to take a user command from Twitch chat and spit out the desired clip. This works relatively simply. 

On boot, you see a small window show up. Click file in the upper left-hand corner, then click connect. You are presented with a connect dialog menu. I CANNOT STRESS THIS ENOUGH. YOU NEED AN ALT TO USE AS YOUR BOT. This program doesn't let you connect if the bot is the same name as your channel. 'OAuth token' is just a fancy way of saying a password. In order to lookup your OAuth, you need to log in to Twitch on your alt, and then click on the button I provide. Copy and paste this into the program, along with filling in the other fields. Click 'Connect.'

Now you are connected. Type !commands in chat to verify you are connected. 

Notes:
I am in no way responsible for any damages caused. It is up to you in being responsible with this. To disconnect this bot from your chat, just close the program. Also, all inputs into this form are remembered for you.

!about - This bot stores a history of clips so anyone could easily reflect on humorous pie-vents! Clips are stored by name, so to access a specific one, enter in !lastrun PieDeathFunny to instantly get a link.

!commands - The commands !lastrun or !lastrun ClipName are available to everybody. The commands !addLast and !removeLast are only available to mods and the broadcaster. All commands are case sensitive.

modCommands - !addLast adds a clip you specify along with the associated keyword. Format is !addLast ClipURL, Name. To remove from database, type !removeLast Name. To remove from Last but keep the clip in the database, just type '!removeLast.'

This program saves more than just clips. this can be used to save text and other links, too!
